# Chapter 21: From Curiosity to Product

*Turn a demonstrated capability into a bounded offer, test it with an identifiable buyer, deliver against agreed criteria, and preserve the difference between interest, purchase, acceptance, and an outcome that has not yet been observed.*

## The question the working system cannot answer

Maya can now explain, draft, review, and recover a particular kind of work. Her Fieldwork records show how to turn supplied meeting notes into source-faithful action-list examples and how to build an activity around that performance. She has also designed procedures for delegation, review, and handling interruptions. None of those records can tell her whether an independent educator wants to buy the resulting service.

That question changes what she must do next. Another synthetic note can reveal an extraction error. Another recovery rehearsal can reveal a missing dependency. Neither brings a buyer's priorities, alternatives, or budget into the evidence. A system that reliably makes something unwanted still has an unanswered business problem.

This chapter introduces the running case's first buyer conversations and pilot. The whole account remains fictional. Its three conversations, two proposals, one agreed paid pilot, quotations, feedback, and delivery events are constructed teaching scenes. They are not transcripts, author memories, or evidence about an actual market. Their purpose is to make a small commercial experiment inspectable, including its disappointing parts.

The move is modest. Maya will speak with three independent educators who consent, within the story, to discuss their workshop-design work. She will prepare two candidate pilot proposals and agree one pilot at an illustrative price of USD 300. She will deliver a reviewable pack and discover that producing an acceptable result can take more work than the price comfortably supports. No learner outcome is established by the end.

Bring your capability demonstration and enterprise runbook. The [product-experiment artifact](../artifacts/21-product-experiment.md) connects them to a buyer question, a specific offer, and a result you can interpret without changing its meaning after the fact.

## Define the product through a useful change

A product is something a buyer can understand, choose, receive, and use for a purpose. It can be a service, an educational resource, a software tool, or a combination. For this book's exercise, it needs a defined result and a way to recognize whether the promised delivery occurred. Packaging every skill you possess into one offer usually makes both harder to see.

Maya's first formulation is too broad: “AI-supported learning design for independent educators.” It describes an approach and an audience, but leaves the buyer to imagine the useful change. Does Fieldwork write a course, review an exercise, facilitate a session, or provide software? The ambiguity can hide a mismatch until after a buyer has agreed to something different from what Maya intended.

She narrows the candidate offer: review one existing thirty-minute workshop brief, redesign one activity so participants produce work the educator can inspect, and return a pack the educator can rehearse. This uses the capability she has practiced. It also creates a boundary around the unfamiliar commercial work. The offer does not require her to build a learning platform or promise an improvement she has never measured.

The buyer's useful change is the center of the description. A reviewed exercise may help an educator replace an unclear activity with a concrete attempt and a basis for feedback. That is a proposed benefit to investigate. “Uses AI” explains part of Maya's production method; it does not explain why this particular educator should interrupt other work or spend money.

Keep three questions separate while shaping your offer. What can you produce? What problem does someone say they need addressed? What are they prepared to commit to obtaining? Your capability record mainly answers the first. Discovery and a bounded offer begin to investigate the others.

## Decide what could change your mind

Maya writes her initial hypothesis before the conversations: some independent educators with an upcoming short workshop will pay for help turning an activity into inspectable participant work. The hypothesis names an audience, a situation, and a proposed purchase. It remains open to several different kinds of correction.

Perhaps educators already have adequate activities and need help finding participants. Perhaps their workshops run for a full day and the thirty-minute constraint is irrelevant. Perhaps they want a second opinion but have no budget. Perhaps the problem is urgent, but Maya's examples fail to show that she can help. These possibilities imply different next actions. Treating every disappointing response as “people do not understand the value yet” would conceal them.

Research on entrepreneurship offers a reason to make the hypothesis explicit. In a randomized study of Italian startups, Camuffo and colleagues taught a treatment group to formulate predictions and test hypotheses, alongside business training received by both groups. The study concerns a particular intervention and setting; it does not establish that a short interview script guarantees a successful offer. ([Camuffo et al., 2020](https://doi.org/10.1287/mnsc.2018.3249))

A later replication and extension across four trials reported increased termination of ideas and a more nuanced pattern of strategic changes, rather than a simple instruction to pivot constantly. One useful implication for this exercise is that learning may justify stopping an idea as well as continuing it. Maya's small practice is an original application, not a reproduction of those trials. ([Camuffo et al., 2024](https://doi.org/10.1002/smj.3580))

Before approaching anyone, Maya records a decision she can actually make. If the conversations reveal no near-term design problem within her capability, she will revise whom she is approaching or which problem she is investigating. If a relevant problem appears, she will offer a narrow pilot. She will not build software merely to avoid hearing a refusal.

## Three conversations, three different situations

The first conversation is with Educator A. Maya explains that she is exploring a small workshop-design service, asks whether the educator is willing to discuss a recent example, and requests permission to retain brief notes for that purpose. This is consent within the fictional scene. It is not permission to publish the educator's material or place unrelated information into an assistant's context.

Maya asks about an actual task in the scene: the next workshop, the current activity, and what the educator finds difficult to judge. She does not begin by asking whether an AI-powered design service sounds useful. That question would invite an opinion about her idea before establishing what happens in the educator's work.

Educator A says: “We talk through the meeting example, but I finish without anything I can check. I need them to make an action list during the session.” The educator has a draft brief for a thirty-minute workshop and can decide whether to commission a small review. The gap fits Maya's practiced capability: an activity needs to produce visible work, with criteria that distinguish a sound answer from a polished-looking one.

The second conversation complicates the hypothesis. Educator B says: “My learners already produce action lists. The difficult part is getting them to arrive prepared.” Maya asks what happens before the session and what has been tried. The problem described is relevant to education, but it is not the same design gap. She records it without bending it into support for the offer she hoped to sell.

Educator C presents a third situation: “I can write the activity. I want another person to check whether it fits the half hour and whether my feedback is clear.” This is closer to a review service than a broad redesign engagement. The educator is interested in a proposal but has not scheduled the next workshop. Maya now has a plausible need with uncertain timing.

These quotes are authored dialogue, reproduced with their constructed status in the artifact. In your own experiment, distinguish actual quotation from paraphrase, inference, and your proposed response. A vivid paraphrase can easily become a supposedly exact customer quote after several summaries. Retain the source wording you are authorized to keep, and label the rest accurately.

Three conversations leave substantial uncertainty. They can expose a mistaken assumption and suggest a smaller next test. They cannot establish how common a problem is across independent educators, or how a different group would respond.

## Interpret the differences before making an offer

Maya's first summary is too generous: “Educators need help turning knowledge into practical workshops.” All three people work in education, but the sentence removes the distinction that matters to her next decision. Educator B described preparation before the session. Educator C described review and timing. Educator A described the absence of inspectable participant work.

She rewrites the record around each person's task. The point of organizing the conversations is to preserve differences that affect the offer, not make them sound like agreement. A repeated phrase such as “workshop problem” should not collapse several different jobs into one imagined demand signal.

She also separates problem evidence from buying evidence. Educator A's description supports the existence of a design gap within the story. It does not yet establish willingness to pay USD 300, acceptance of Maya's scope, or satisfaction with a delivered pack. Those questions require later events. Educator C's request to see a proposal is a next step, not a sale.

Maya decides to prepare proposals for A and C. She does not make one for B, because solving preparation would broaden the task beyond the demonstrated design service. That choice is not a judgment that B's problem is unimportant. It protects the usefulness of the experiment by keeping the offered work close to what Maya can review and deliver.

In your own notes, write the alternative action beside the interpretation. A timing problem may call for a later follow-up if welcome. A capability mismatch may call for a referral or a different experiment. A lack of budget may change the audience or scope. The record should help you act on what was said, including when the appropriate action is to stop pursuing this offer with this person.

## Make a pilot small enough to judge

Before quoting the work, Maya asks to understand the material the pilot would change. An educator's description can establish a difficulty within the conversation, but the existing brief helps locate it. With permission, she looks for the intended participant action, available time, and current method of review. She needs enough context to scope the job, not a copy of every document the educator has ever produced.

The brief may contradict Maya's first interpretation. A visible activity could already exist, with the real difficulty lying in how feedback is used. If so, the proposal should change. Discovery is not complete merely because someone has said the words that fit the service description. The useful question is whether the offered work addresses the particular obstacle the material reveals.

She also asks what the educator would otherwise do. In the fictional case, Educator A could revise the brief alone or ask a colleague for an informal review. Those alternatives affect the useful difference Fieldwork must provide. A comparison with an imagined world where the buyer has no options would make almost any offer appear valuable.

The next request should match the uncertainty. Asking permission to inspect a brief tests access to the work. Asking whether a proposal is worth reviewing tests interest in a next step. Agreeing a specific paid scope tests a purchase decision under those terms. None is a substitute for the others, and none should require the participant to provide material beyond what the particular step needs.

This sequence also gives Maya a respectful stopping point. An educator can decline to share a brief, decide that the timing is wrong, or choose another route. Maya records the outcome without treating refusal as a problem to overcome through more persistent persuasion. The experiment is useful when it improves a decision, including the decision not to pursue a particular engagement.

Maya prepares two proposals, P21-A and P21-C. Each offers a review of one brief, redesign of one activity, and a reviewable pack for an illustrative USD 300. The shared shape makes the offer understandable; the diagnosis in each proposal refers to that educator's stated problem.

The pilot for Educator A, PP21-01, becomes the agreed engagement. Its input is the educator's authorized draft brief and a synthetic meeting-notes exercise. Its delivery contains an annotated review, one revised activity, source-linked example work, review criteria, a facilitator sequence, and a change note explaining the important choices. One bounded revision round is included.

Maya and the educator agree what the pack should allow: the educator can rehearse a thirty-minute session, identify what participants will produce, compare that output with the criteria, and use feedback to guide a revision. These are delivery and rehearsal criteria. Actual learning would require appropriate observation of participant work in a later session, which this pilot does not supply.

The excluded work matters because it can otherwise arrive disguised as helpful completion. The pilot does not include a complete course, branded slide deck, software platform, live facilitation, recruitment, or unlimited revisions. A new request can be considered, but it does not silently become part of the agreed USD 300 package.

Educator A agrees to the paid pilot. Educator C defers because there is no scheduled session to prepare for. The second proposal therefore remains unaccepted; Maya does not count it as future revenue. Nor does she treat one agreement from two proposals as a dependable conversion rate. The people and circumstances were selected for a tiny exploratory exercise, not a representative forecast.

## Turn agreement into a workable delivery boundary

An accepted offer must become specific enough to guide ordinary work. Maya records the input she may use, the deliverables, the revision allowance, the agreed fee, the review date or condition, and the person who accepts the pack. If those details live only in a pleasant conversation, the workflow will have to infer them later.

She keeps buyer communication in her own hands. An assistant may help draft a proposal or organize authorized design material. The earlier delegation contract does not acquire permission to contact Educator A, publish the pack, change the agreement, or make claims about participant outcomes. Those actions have different consequences from producing a draft in the project workspace.

This is where the enterprise runbook becomes useful. The accepted pilot enters as actual work within the fictional story, carrying its particular source and scope. Earlier internal practice cards remain simulations. Their estimated effort cannot be substituted for the time this engagement actually requires, even when the task looks familiar.

The pilot also exposes a scheduling question. Chapter 20's internal package slots were assumptions for much smaller rehearsals. A customer engagement that requires several hours cannot be promised inside one such slot. Maya reserves an appropriate window and does not add unrelated commitments until she can see the work the pilot requires.

The product record distinguishes agreement from payment. USD 300 is the agreed fee in this illustration. A signed-off pack, an issued invoice, earned revenue under a stated accounting treatment, and collected cash are different states. This chapter establishes no payment receipt. Keep those labels separate when preparing the economics model rather than calling every agreed fee money already available to spend.

## Deliver the promise and inspect a real defect in the example

The first proposed pack looks useful. It contains an individual action-list attempt, source-based criteria, and feedback that explains why an unsupported owner or date should be corrected. The earlier learning-design work survives. Yet its session sequence takes thirty-six minutes: five for orientation, eight for a model, ten for the attempt, eight for review, and five for closing.

The agreed workshop is thirty minutes. The defect is arithmetic and scope, not a newly discovered need for individual practice. A document can contain sound parts while failing as a usable whole. Maya's internal review should have caught the mismatch before handing over the candidate.

In the constructed feedback scene, Educator A says: “The activity is clearer, but these parts add up to thirty-six minutes. I cannot fit that into the session we agreed.” Maya records the comment as a delivery defect. She does not defend the extra time by repeating why feedback matters, or report the positive first clause while omitting the constraint that made the pack unacceptable.

Her repair preserves the learning operation while narrowing the content. The revised sequence allows three minutes for orientation, five for a short worked model, eight for the individual attempt, eight for comparison and revision, and six for closing and the next action. The total is thirty minutes. She shortens the model and removes an optional discussion instead of taking away the participant's opportunity to try and revise the task.

The revised example remains grounded in synthetic notes. Its action-list answer still preserves agreements, suggestions, named owners, unspecified assignments, and unresolved timing under `instructions-v3`. Commercial pressure does not justify making the answers look complete by inventing a commitment. Maya checks both the session total and the source-based output after the repair.

Educator A accepts the revised pack as ready for their own rehearsal. It is narrower than successful facilitation, learner improvement, repeat demand, or an independently measured time saving. The artifact supplies the brief constraints, both agendas, feedback, and revised acceptance so you can inspect the exact change without imagining a missing successful workshop.

## Preserve feedback at the level it can support

Feedback may concern the offer, the delivery, or the eventual use. These are related but require different responses. The thirty-six-minute agenda reveals a delivery mismatch. It does not establish that the educator's original problem was imaginary or that no one will pay for workshop review. Maya repairs the part the evidence identifies.

Equally, accepting the repaired pack does not settle the larger product question. The educator might use it successfully and never need another. A second educator might need extensive customization. The work might be useful but expensive to deliver. The experiment record should preserve these possibilities rather than converting one acceptance into the phrase “validated product.”

Maya updates `product-experiment-v1` with distinct entries: three discovery conversations; two proposals; one agreed paid pilot; one candidate requiring timing repair; one revised pack accepted for rehearsal. She leaves learner performance and repeat buying unresolved. These are counts of events in an authored case, not research findings about the market.

She also records the correction in the right place. The source-faithfulness instruction does not need a new version because the agenda exceeded its agreed duration. The delivery review needs an explicit total-duration check before a pack is returned. A new problem should change the procedure responsible for it, preserving the boundaries already working elsewhere.

For your own pilot, retain the feedback that could embarrass a success story. A precise complaint is often more useful for the next decision than a general compliment. Connect the repair to the particular version the buyer reviewed so later work can tell whether the issue was corrected or merely discussed.

## Count the work the first purchase required

The pilot gives Maya another kind of evidence: the effort involved in obtaining and serving a buyer. The illustrative record allocates four hours to delivery, including the timing repair, two hours to acquisition across the three conversations and two proposals, and one hour to support. Cash costs allocated to the experiment are USD 20. These are constructed case figures, not measured business results.

Seven hours of owner work sit behind a USD 300 agreed fee. A reader who subtracts only USD 20 sees a large remainder, but that arithmetic leaves Maya's time unpriced. A reader who counts only the final edit overlooks the conversations, proposal writing, and clarification that enabled it. Both accounts can make an unsustainable offer look comfortable.

Chapter 22 will examine the illustration using a USD 50 hourly value for owner time. That value is an assumption for decision-making, not money the example proves Maya paid herself or an authoritative market wage. With USD 300 treated as earned revenue for that calculation, USD 20 of cash cost and USD 350 of owner time produce a negative USD 70 economic contribution.

Do not solve this discovery by declaring that AI will remove the difference. Identify which work took time and why. Some effort may be an initial learning cost. Some may recur for every buyer. Some may be a consequence of a scope that needs changing. A credible second experiment makes a specific alteration and checks both delivery quality and total effort.

Maya now has a useful commercial question: can she retain the part the educator valued while reducing unnecessary work or agreeing a different price and scope? The first purchase makes that question more concrete.

## Choose a form that fits the work you can inspect

A service is a reasonable first form when judgment and adaptation remain central. The buyer can bring a particular brief, and Maya can learn which parts vary. Repeated patterns may later justify a more standardized pack. Standardization should follow a stable useful operation, rather than forcing every buyer into a template whose assumptions remain untested.

An educational product could be a self-guided activity kit with examples, criteria, and a facilitator guide. Its next experiment would need to examine whether the intended user can use those materials without Maya explaining every step. A sale alone would not show that the kit teaches the intended performance. The product's support burden and observed use become part of the inquiry.

A software product could help an educator assemble or review such a pack. That proposal adds questions about input handling, mistakes, accessibility, maintenance, and whether the automation saves enough work to justify itself. Before building an application, Maya could test the proposed interaction with an ordinary document and a manually delivered result, honestly described as a manual service.

These routes can coexist, but they should not be blended to hide an uncertain promise. A buyer purchasing a reviewed service expects Maya's judgment. A buyer purchasing a resource expects to use it with the described support. A software user expects the stated behavior to work under stated conditions. Each form changes what has to be delivered and what a meaningful test should inspect.

The Future Is Solo presents systems and individual judgment as a route to creating value at greater scale. That is the project's economic thesis, not evidence that a particular product has demand. Applying it here means investigating a useful exchange and its working conditions before expanding the machinery around it. ([The Future Is Solo, n.d.-b](https://thefutureissolo.com/))

The TFIS experiment deck provides a related development example: its lead-generation entry describes a self-assessment for prospects, drawing on earlier memory and course experiments. The stated purpose reaches toward a prospective audience. The slide does not establish qualified leads, purchases, or validation of the assessment. An artifact intended to attract people still needs evidence about what those people do with it. ([The Future Is Solo, 2026, slide 36](https://docs.google.com/presentation/d/1dvbBGs22QvtGogevZ6f5mf8YQE7WDAPBwYlclhTyctI/edit#slide=id.g3f2efd984cc_0_9))

## Design the next experiment from the remaining uncertainty

Maya does not leave the pilot with a larger feature list. She leaves with several possible questions and must choose among them. Can an educator rehearse the pack without extra explanation? Which part of delivery consumed the four hours? Would a narrower review command enough value at a sustainable price? Does the same problem appear in a different educator's current work?

Choose the next question that matters to the decision you face. If the pack cannot be used, acquiring more buyers magnifies an unresolved delivery problem. If it works but costs too much to deliver, another identical pilot may only repeat the loss. If the audience mismatch remains the main uncertainty, refining the production workflow may have little effect on demand.

A decision to stop or narrow the offer can be a successful result of the experiment. You have avoided making a larger commitment on an unsupported assumption. Curiosity remains productive when it changes what you build, whom you serve, or what you decline to promise.

## Field assignment: put one bounded offer in contact with a buyer

Complete the [product experiment](../artifacts/21-product-experiment.md). Start with a capability you can demonstrate and a particular situation in which it might help someone. State the uncertainty, the evidence you need, and what would lead you to continue, revise, or stop. If you are not ready to approach people, rehearse with the supplied fictional packet and label that rehearsal honestly.

For actual discovery, explain your purpose, obtain appropriate agreement to discuss and retain the material, and ask about concrete work before pitching a solution. Keep your own quotations, paraphrases, inferences, and proposals separate. A small number of conversations can guide a next step without supporting a claim about the whole market.

If a relevant buying situation emerges, prepare a bounded offer with input, delivery, acceptance criteria, limits, price, and review process. Keep human communication and commitments under your control. Deliver only within the agreement, record actual feedback, and preserve any failed candidate alongside its repair. Record time and cash separately, including acquisition and support.

Without AI, explain what each result establishes. Show the difference between a problem account, an invitation to propose, an agreed fee, collected cash, an accepted delivery, and an observed user outcome. Your experiment passes when another person can inspect the record and understand why you chose the next action. [Chapter 22](22-from-product-to-value.md) asks whether that action can support an economically useful operation.

## References

Camuffo, A., Cordova, A., Gambardella, A., & Spina, C. (2020). A scientific approach to entrepreneurial decision making: Evidence from a randomized control trial. *Management Science, 66*(2), 564–586. https://doi.org/10.1287/mnsc.2018.3249

Camuffo, A., Gambardella, A., Messinese, D., Novelli, E., Paolucci, E., & Spina, C. (2024). A scientific approach to entrepreneurial decision-making: Large-scale replication and extension. *Strategic Management Journal, 45*(6), 1209–1237. https://doi.org/10.1002/smj.3580

The Future Is Solo. (n.d.-b). *The future is solo*. Retrieved September 10, 2026, from https://thefutureissolo.com/

The Future Is Solo. (2026). *The Future Is Solo 20260910* [Google Slides presentation]. https://docs.google.com/presentation/d/1dvbBGs22QvtGogevZ6f5mf8YQE7WDAPBwYlclhTyctI/edit

<!-- sources: camuffo2020, camuffo2024, TFIS-HOME, tfis-experiments-20260910 -->
