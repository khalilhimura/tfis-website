# Chapter 14: The Cognitive OS

*Use a short operating manual to start, review, interrupt, and finish ordinary work while keeping current instructions, evidence, human decisions, and verified records connected.*

## The system has to work on an ordinary morning

Maya has accumulated useful records. She can locate current instructions through `learning-loop-v1`, recover their rationale, inspect a distillation, and follow relationships in her knowledge map. The verdict ledger preserves a correction and its limits. Each document solves a recognizable problem.

An ordinary morning creates a different test. She opens her working folder with limited time and several possible next steps. One note proposes another exercise. Another asks whether the latest record was saved. A third contains a useful but superseded instruction. Nothing in the folder selects today's task for her.

She could spend the session improving the arrangement. She could also begin drafting from the nearest paragraph and recreate a mistake the arrangement was meant to prevent. Neither choice follows automatically from having a well-organized collection.

Maya's immediate task is another synthetic action-list example for the thirty-minute workshop, still without customer or learner outcomes. Her ordinary-day problem is coordination: what to do first, when to pause, and what state to leave for the next session.

This chapter joins the practices you already have. Bring the inventory, charter, memory locations, current instruction route, knowledge map, and verdict ledger. You will turn their relationships into a small [operating manual](../artifacts/14-operating-manual.md) that someone can follow while doing the work.

## Treat the title as a practical metaphor

An operating system coordinates resources and operations in a computer. “Cognitive OS” here is a metaphor for the procedures through which you direct work, consult external memory, review results, and preserve consequential changes. It does not mean that a folder reproduces a human mind or that a new application can take responsibility for your judgment.

The metaphor is useful only where it makes an operation clearer. When a task begins, which records are loaded? When evidence conflicts, who decides what happens next? When a correction is accepted, where is it written? When the session ends unexpectedly, what allows another session to resume?

You can answer those questions with ordinary documents. The four locations from Chapter 10 remain working context, project workspace, reviewed durable memory, and portable archive. The knowledge map remains a route among records. The charter still governs retention and authority. The operating manual says when to use each one.

Avoid giving every step a new name. A reader who must memorize another vocabulary before beginning has acquired an additional dependency. Maya's manual uses familiar verbs: choose the task, retrieve the applicable records, check the input, draft, review, save approved material, verify the result, and leave a handoff.

Maya can perform the procedure herself, ask an assistant to draft one part, or later delegate a bounded sequence. The manual identifies which arrangement she is using.

## Begin when there is a task, not merely an open application

An application can present an empty prompt and invite work without helping you decide what is worth doing. Start with the intended result instead. Maya writes: “Prepare one reviewable action-list example from the supplied synthetic notes, using the current evidence rules.”

That statement excludes several nearby tasks. She is not redesigning the offer, resolving real meeting commitments, or preparing customer outreach. The distinction matters because each would require different evidence and permissions. A short statement of purpose prevents convenient available material from silently selecting the work.

A trigger is the event that causes a procedure to begin. For this manual, Maya uses concrete triggers: a new practice input is ready; an output reveals a discrepancy; a current decision changes; a session is interrupted; or a completed session needs a handoff. A trigger should be recognizable without asking the assistant to infer an entire project strategy.

Not every trigger deserves immediate action. A newly saved article may be interesting without affecting the current task. A proposed correction can wait in the review queue while its support is incomplete. The manual should say what is ready to enter the working session and what remains pending.

Maya chooses one bounded task because she can review it in the time available. If she generates more outputs than she can inspect, the remaining drafts stay drafts. Producing a larger pile does not change their authority. The practical limit is the amount of work she can finish with the necessary judgment intact.

## Follow the current route before collecting context

Maya begins at the project index, which leads to `learning-loop-v1` and its current-instruction pointer. She follows that route before assembling the working packet. A useful paragraph found through search can explain a rule, but search position does not make it the applicable instruction.

The knowledge map helps her locate the rationale, distillation, relevant examples, and verdict. Each relationship retains its meaning. A link saying that a verdict was supported by an example does not mean the example authorizes a new action. A record marked historical remains historical after it enters the current session.

Her working packet identifies the task, the current instruction location, the supplied input, the required output form and review criteria, and the review boundary. She adds the relevant rationale when interpretation requires it. At this point in Fieldwork, that route selects `instructions-v3`, including the approved conflict-handling behavior from Chapter 11 while preserving the earlier rules about owners, suggestions, and imprecise timing.

Anthropic's context-engineering guidance describes retrieving selected information through references and using structured notes to continue work across sessions. It also describes the risk of losing important details through excessive compression. These are engineering practices and observations, not proof that one packet will suit every task or model. ([Rajasekaran et al., 2025](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents))

For this manual, the useful question is concrete: does the packet contain the material this attempt needs, with its status intact? If the task depends on a conflict between two passages, include both. If a short summary conceals the conflict, it is an inadequate substitute even when the source links remain somewhere in the wider project.

## Inspect the boundary of the task before drafting

Before using the packet, read it for authority and readiness. Is the instruction actually current? Is the input clearly distinguished from the instruction? Is the material authorized for this task? Are there missing dependencies that would make the requested output misleading?

Maya does not need a lengthy ceremony for every synthetic paragraph. A brief inspection can answer these questions. The effort should follow what could change the result. A new source containing two incompatible deadline statements deserves more attention than a harmless change to the title of a known example.

If the packet contains an instruction inside a source, that text remains source content unless separately authorized. If it contains a claimed user preference that was never approved, the manual does not let the claim become a lasting rule. The charter's boundaries travel into the session; they do not disappear when drafting begins.

Readiness also concerns the next action. A packet may be sufficient to identify a conflict and insufficient to resolve it. The proper output can therefore be a useful partial account plus a request for clarification. A stop condition should identify the unsupported action being stopped, rather than unnecessarily erasing work the evidence does support.

Write that distinction in the manual. “Do not select a single deadline when the supplied passages disagree without a supported superseding decision” is more actionable than “be careful with ambiguity.” It identifies a condition a reviewer can inspect.

## Worked session: the input and the draft

Maya prepares a new synthetic note for this chapter. It changes the specific commitments while preserving the distinctions the existing instructions govern:

> S14:1 The facilitator agreed to send the revised exercise notes on Thursday.
>
> S14:2 The group agreed to ask the venue about access soon; no owner was assigned.
>
> S14:3 A reminder on Friday was suggested, but no decision was made.

This is an invented teaching input, not a new report of a real meeting. The current task is to represent it faithfully. The manual asks for a draft that keeps actions, owners, timing, and status visible enough for review.

One acceptable output is:

| Item | Status | Owner | Timing | Source |
| --- | --- | --- | --- | --- |
| Send revised exercise notes | Agreed | Facilitator | Thursday | S14:1 |
| Ask the venue about access | Agreed; assignment unresolved | Not assigned | “Soon”; exact date unspecified | S14:2 |
| Send a reminder | Suggested; no decision made | Not established | Friday proposed, not confirmed | S14:3 |

The table's wording may vary. Its important properties are inspectable against the input. It retains the explicit Thursday commitment. It does not assign the venue task to the facilitator merely because the facilitator is the only named role. It preserves “soon” without inventing a date. It keeps the reminder's proposed timing separate from a confirmed commitment.

Maya asks an assistant for the draft, or writes it herself using the same packet. Assistance changes who performs the first attempt. It does not change what would count as a supported result. The review can now point to particular cells and source phrases instead of judging whether the output looks professionally formatted.

## Review the result against evidence, not familiarity

A familiar task invites a quick approval. The earlier corrections may make the output feel safe because the rule is now well established. That feeling is not a substitute for comparing the new result with the new input.

Imagine the generated list assigns the venue inquiry to the facilitator and changes “soon” to Friday. The row now looks complete. It also contains two unsupported details. Maya identifies the exact row and the source passage, rather than issuing a general instruction to “be more accurate.”

The relevant earlier verdict can help explain why those details are unacceptable. It cannot supply the correct owner or date, because the source does not establish either. The repair must return to the input and preserve its gaps. Repeating an old corrected answer would be another way to lose contact with the present task.

Maya records a rewrite decision when a consequential correction needs to be retained. The reason states the violated boundary and its scope. She then inspects the repaired output. A decision that says “rewrite” does not establish that the rewrite occurred, and a saved verdict does not establish that a later attempt used it.

When the output already meets the criteria, she can record a bounded acceptance. The object is this synthetic output under these conditions. It is not approval of the workshop's effectiveness or of every future action list. The verdict ledger keeps those meanings separate.

## Keep review decisions separate from completed changes

A daily procedure needs to distinguish what was decided from what happened afterward. Maya may approve wording in the conversation, but the saved project file can still contain the previous version. She may request a rewrite that remains unfinished when the session ends.

The manual gives these states plain descriptions. A proposed record awaits review. A reviewed decision identifies the approved action or wording. A saved-change check establishes what appeared in the intended location. A later reuse check examines whether that record influenced the next attempt. The verdict's type and the completion of these operations are separate facts.

The Functional Life describes durable accept, reject, and rewrite judgments and emphasizes checking the stored state left by a change. This chapter applies those stated practices to a small document procedure, with Maya remaining responsible for consequential meaning. ([The Future Is Solo, n.d.-a](https://life.thefutureissolo.com/))

After approving a retained correction, Maya opens the relevant ledger entry from the project location. She checks the exact target, the reason, and the links. If she changed a current instruction, she follows the existing pointer again. If no instruction changed, she does not update unrelated records merely to make the session look productive.

Retain the evidence the next task needs and decisions likely to matter later, using the charter's existing review rules. Most successful examples will not require a new general principle.

## Worked interruption: preserve what is unresolved

Later, Maya prepares another synthetic input with two supplied statements:

> A:1 The facilitator agreed to circulate the revised outline on Monday.
>
> B:1 The facilitator agreed to circulate the revised outline on Tuesday.
>
> The packet does not establish which passage came later or whether either supersedes the other.

The current conflict-handling instruction already covers this situation. A useful output retains the shared action and owner, identifies the conflicting Monday and Tuesday claims, and says that the applicable deadline requires clarification. It should not treat the second passage as a later decision merely because it appears second.

Maya can complete that representation and still lack authority to choose the date. Before clarification occurs, she must stop the session. The ordinary-day procedure now needs to preserve a boundary rather than manufacture a finished answer.

Her handoff says: “Shared action and owner extracted. Deadline conflict remains Monday versus Tuesday; no superseding evidence supplied. Output is ready for review as an unresolved account, not a confirmed schedule. Next action: obtain an authorized clarification if this task is to continue beyond representation.” It links to the input and the draft.

No actual clarification is obtained in this fictional exercise. The handoff records the condition that would allow further work. If the next session begins without that evidence, the condition remains unmet. A new conversation does not turn an unresolved issue into permission to improvise.

## Resume from the record, then compare it with the present

Resuming means recovering enough state to continue appropriately. It does not mean blindly reenacting the final instruction from the previous conversation. A task, source, permission, or current rule may have changed while the work was paused.

Maya starts from the handoff and follows its links. She confirms that the current instruction route still applies and that the pending issue remains unresolved. If new evidence has arrived, she identifies it separately and determines which part of the earlier account it changes. The earlier record should not silently absorb a new decision without its origin.

The resumption check also catches incomplete writes. Suppose the handoff says that a corrected output was saved, but its link opens the unrevised draft. Maya treats the stored file as the state she has, while using the reviewed decision to identify what was intended. She repairs the save and reopens it before relying on the correction.

That is an operational failure even when the reasoning was sound. It calls for fixing the destination or write procedure, rather than revisiting the entire evidence rule. A good manual helps distinguish these cases so that every interruption does not become a project restart.

When you cannot establish which state is valid, keep the active work intact and use a separate inspection copy. The next chapter develops that recovery discipline further. The immediate principle is to avoid allowing a hurried resumption to overwrite uncertainty or later approved work.

## Recognize when the task changes the rule's scope

A procedure can be followed correctly and still be inappropriate for a new task. Suppose Maya later asks for a draft planning recommendation rather than a faithful account of meeting commitments. In that different task, suggesting a possible owner may be useful, provided the suggestion is clearly labeled and Maya reviews it. The current representation rule does not authorize treating the suggestion as an agreement.

The manual should make the change of task visible. A note saying “propose options for unresolved assignments” is different from “extract the assignments established in these notes.” If the request blends both, separate the outputs so that the source-based account remains inspectable and the proposed options cannot quietly overwrite it.

Maya does not need to modify the current action-list instruction merely because another task could use a different approach. She needs to identify the new purpose, its permission boundary, and its review criteria. If the work proves recurring, a separate bounded procedure may be appropriate. Until then, an explicitly reviewed one-off task can be enough.

This distinction also protects useful judgment from becoming rigid compliance with a remembered slogan. “Never invent a commitment” governs how an established agreement is represented. It does not forbid considering possibilities. The important boundary is whether the output tells the reader which statements are supported and which are proposed.

When the manual and a new request seem to disagree, pause the dependent action and compare their scopes. An assistant should not silently expand the old rule or ignore the new request. The person directing the work can clarify what is being asked and which record, if any, should change.

## Continue a small task when assistance is unavailable

Maya can run the first worked example without an assistant. She reads the current instruction, draws the table with its source-reference column, and fills each row from the source. She then reviews her own draft against the same passages. The output may take a different amount of effort, but the evidence standard remains the same.

This manual route is useful for more than an outage. It reveals which parts of the workflow Maya understands and which depend on unexplained application behavior. If she cannot identify the applicable rule without asking the assistant, the index or her understanding needs attention before she delegates more.

Manual work can also contain familiar errors. Maya might carry a facilitator assignment from the first sentence into the second without noticing that the venue inquiry has no owner. The review procedure should catch that mistake regardless of who produced it. Human authorship does not exempt a draft from the evidence check.

Record the substitution honestly in the handoff: the task was completed manually using the current packet, or it remains pending because a required capability was unavailable. A procedure that admits these states is easier to resume than one that assumes an assistant was always present and every automated step succeeded.

## Set review capacity before increasing production

A solo operator's attention is part of the system. The manual should reflect the time and understanding available for review, rather than assuming an unlimited supply. An assistant that produces drafts quickly can make this boundary easier to overlook.

Maya starts with one new example and one changed-input check. That is an illustrative working choice, not a validated optimum. If she can review only the first, the second remains pending. If a discrepancy needs careful inspection, she reduces the number of additional drafts entering the queue.

Useful queue information is modest: what the item is, why it is pending, what must happen next, and which record it depends on. A large list with no next action can become another place where unresolved work disappears. The operating manual should make the most consequential unfinished items visible without requiring a dashboard.

You can also choose a manual action because it costs less attention than supervising automation. For a short ambiguous note, reading it directly may be more efficient than writing an elaborate delegation instruction and checking several outputs. This does not represent a failure to advance. It is a decision about the work under current conditions.

Increase the volume or autonomy only after the existing procedure shows what review costs and where mistakes occur. The goal of accumulation is usable capability. Producing more unreviewed material can move you away from that goal even while every activity counter rises.

## End with a state the next session can inspect

A useful session ending answers a small set of questions. What was completed? What was accepted, rejected, or left pending? Which records actually changed? Which pointers or links were checked? What is the next authorized action?

Maya's handoff is concise because the project records carry the detail. It links to the relevant input, output, verdict, and current instruction route. It preserves the unresolved customer hypothesis and any active practice conflict. It does not repeat the whole history of Fieldwork.

She closes the session only after the necessary saved-state checks, or explicitly records which check remains unfinished. “Awaiting verification” is a meaningful state. Calling the task complete while the verification is pending makes the next session depend on a false premise.

The archive receives a selected recovery package when the current state warrants one under the charter. Every session does not need a full snapshot. A consequential instruction change, a meaningful milestone, or an upcoming move may justify a new package. The restore note should identify what it contains and which dependencies remain elsewhere.

This ending gives the next session a starting state, including the questions it still needs to resolve.

## Keep the manual shorter than the work it governs

An operating manual can become a burden if it describes every possible action in advance. Begin with the situations that have already mattered: finding the current rule, preserving source status, handling a discrepancy, verifying a write, and resuming after interruption.

Use links for detailed criteria. The manual can point to the charter for permission rules and to the current instruction for output behavior. Repeating them in full creates competing copies that can drift. A short reminder may be useful, but it should identify its role and the governing record.

Review the manual when an ordinary use reveals an omission. If Maya repeatedly forgets to follow the current pointer, the start procedure needs a clearer cue. If a stop condition is too vague, specify the unsupported action it blocks. If nobody uses a long ceremonial section, remove or simplify it while preserving the necessary boundary.

Judge the manual by whether another session can follow it and leave a recoverable state. A short procedure with useful links may be all the work needs.

You should still understand the procedure without opening it. External records support continuity; they do not relieve you of knowing what you are authorizing. If you cannot explain why a review gate exists, return to the concrete failure it was intended to catch.

## Use the same operations in different work

For a service professional, the trigger might be a request to prepare a proposal from an agreed scope. The current scope record governs the draft. Internal suggestions remain proposals, and sending the document is a separate action with its own authorization. The handoff identifies unresolved terms rather than smoothing them into an apparent agreement.

For an educator, the task might be revising an exercise after reviewing authorized learner work. The packet distinguishes the observed work from an explanation of why learners struggled. The teacher approves the design change and checks the saved lesson version. A later lesson can test the change; the revision itself does not establish improved learning.

For a software builder, the trigger might be a reproducible defect. The packet includes the reported behavior, a relevant requirement, and a bounded proposed change. The review distinguishes a plausible explanation from a demonstrated result. The handoff states which checks ran and what remains unresolved, rather than treating a code edit as proof the defect is fixed.

Each example requires its own expertise. The procedure makes the points needing domain judgment—and their supporting evidence—visible.

## Field assignment: run a day in miniature

Complete the [operating manual](../artifacts/14-operating-manual.md) for one recurring task. Name the triggers, starting route, required packet, human review points, stop conditions, saved-state checks, and handoff. Link the existing records that govern those operations.

Run one bounded session with an inspectable input and output. Then rehearse an interruption while something remains unresolved. Resume from the saved handoff and check whether it preserves the intended next action without depending on the previous conversation.

Record a failure if the wrong instruction is loaded, the output exceeds its evidence, a saved change is missing, or the resumed task invents a resolution. Repair the operation responsible and repeat the relevant part. Do not rewrite every document merely because one link was wrong.

Your manual passes this book's practice check when a person can follow it to produce a reviewed result, distinguish a decision from a completed write, and leave a usable handoff. This is evidence about a stated workflow, not automatic certification at an SSA-CMM level.

Without AI, explain what would cause you to stop, what would justify continuing, and what would demonstrate that an accepted change survived. Maya finishes with `operating-manual-v1`, connecting her existing records without replacing their authority. [Chapter 15](15-the-sovereignty-test.md) tests whether that procedure can still work when the familiar environment is no longer the starting point.

## References

Rajasekaran, P., Dixon, E., Ryan, C., & Hadfield, J. (2025, September 29). *Effective context engineering for AI agents*. Anthropic. https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents

The Future Is Solo. (n.d.-a). *The functional life* (Field Manual No. 01). Retrieved September 10, 2026, from https://life.thefutureissolo.com/

<!-- sources: rajasekaran2025, TFIS-LIFE -->
