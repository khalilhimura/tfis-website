# Chapter 3: Curiosity Is a Capability

*Develop the ability to choose an inquiry that can improve a piece of work, pursue it within a useful boundary, and preserve the next question without abandoning the current one.*

## The browser is busy; the project is waiting

Maya has a working brief, a record of her early attempts, and a ledger that separates claims from evidence. She also has a growing collection of things to read. There are articles about workshop design, examples of attractive learning materials, discussions of AI tutors, and demonstrations of tools that could eventually help Fieldwork. Each item seems connected to her proposed studio. Together, they are becoming a second project.

Her untested business question remains: do independent educators need help specifying what learners should be able to do? A generic workshop template might help with presentation while leaving that harder decision untouched.

One afternoon, she opens a saved article to improve `workshop-brief-v1`. A link leads to a discussion of assessment. Another leads to a system for generating course materials. She watches a demonstration, compares two products, and saves a third for later. When she returns to the brief, she cannot point to a decision that has changed. The session contained interesting material. It did not answer the question she had intended to investigate.

This does not mean the reading was worthless. Some of it may become useful. The immediate problem is that she cannot distinguish purposeful exploration from a sequence of plausible detours. Everything has a connection to education if she describes the connection broadly enough. “This might help the business” has become permission to investigate almost anything.

She closes the extra tabs and writes a more demanding sentence: “By the end of this session, I want to make one part of the brief easier to evaluate.” The sentence does not tell her what to read. It tells her what the reading needs to accomplish. Her next task is to choose a question whose answer could make that improvement possible.

You will make the same choice in this chapter. Bring the output you developed in Chapter 1 and the claims ledger from Chapter 2. If those are incomplete, bring a small unfinished piece of work and label the gaps. You need a real object to inspect, not a fully developed business idea.

## Notice the gap that affects the work

Curiosity often begins before there is a well-formed question. Something surprises you. A procedure works in one situation but fails in another. You recognize a term without being able to explain it. A customer asks for a result you do not yet know how to produce. These moments supply material for inquiry, but they do not automatically identify its best direction.

Look at the work itself. Where did you hesitate? Which statement required you to guess? What correction did you make without understanding why it helped? A gap is especially useful when you can locate it in a document, an action, or a decision. “I should learn more about education” is difficult to act on. “I cannot tell whether this activity gives the learner a chance to practice the stated task” points to something you can examine.

Maya finds three different gaps. She does not know whether educators would pay for help with workshop briefs. She does not know how much structure such a brief should contain. She is also unsure whether the proposed learner outcome can be checked. These uncertainties are related, but they require different work. Reading a research paper cannot establish demand for Fieldwork. Asking someone whether a document looks useful cannot establish that learners acquire a skill.

She writes the uncertainties separately. Improving the task description can guide her preparation; demand and effects on learners need their own inquiries.

Start with one of your own hesitations. Describe what you were trying to do when it appeared. Then finish the sentence, “If I understood this better, I could decide whether to…” If you cannot name a possible decision, the interest may belong in open exploration for now. It need not become today's project inquiry.

## Give curiosity somewhere to land

There is a difference between having interests and being able to investigate them. An interest can last for years without demanding an answer. An inquiry asks you to produce something: an explanation, a comparison, an observation, or a tested change. This book treats the ability to make that transition as a capability you can practice.

It does not require you to feel fascinated by every necessary task. You can investigate a confusing invoice, a failed import, or an unclear sentence because the work matters, even when the subject feels ordinary. Nor does it require all your reading to justify itself economically. Reading for pleasure, conversation, and unplanned exploration belong in a life that contains more than a business.

The distinction becomes useful when you decide what kind of time you are spending. During open exploration, you can follow an unfamiliar connection without promising an immediate output. During a project inquiry, you owe the project a result or a clearer account of why the question remains unresolved. Mixing the two without noticing can make both frustrating: exploration feels guilty, and the project feels permanently unfinished.

Maya keeps space for both. She can read broadly about how people learn without claiming every article advances Fieldwork. When she returns to the brief, however, she chooses a question tied to its next revision. The boundary protects a particular session. It is not a rule against intellectual wandering.

You can use an ordinary calendar note to make the distinction visible. Write the purpose of the session beside its duration. At the end, assess the session against that purpose. A good exploration session may leave several interesting questions. A good inquiry session should leave a usable answer, a justified provisional decision, or a precise description of the missing evidence.

## What the research supports

Research gives us a reason to take interest seriously without turning it into a promise of mastery. Gruber and colleagues studied curiosity about trivia answers and memory for both those answers and incidentally presented faces. Higher-curiosity conditions were associated with better memory on immediate and one-day-delayed tests. The study also examined brain activity associated with these effects. It did not test business founders, unrestricted browsing, or this book's exercises. ([Gruber et al., 2014](https://doi.org/10.1016/j.neuron.2014.08.060))

The practical extension here is modest: begin by making the unresolved question visible to yourself. You do not need to manufacture excitement or search for a neurological shortcut. A question connected to a decision gives you a reason to attend to the answer. Whether that answer becomes useful still depends on what you do with it.

Suppose Maya reads an explanation of an assessment method and finds it compelling. That feeling does not show that she can design a suitable assessment. She needs to attempt one, compare it with the intended learner task, and examine the mismatch. Interest can open the work. Application gives her something to inspect.

When a subject feels slow or confusing, a small, concrete question still gives you somewhere to begin. You can practice investigation without waiting for inspiration.

## Draw a map around the unfinished brief

Maya writes the proposed benefit at the center of a blank page: “Help an educator design a short workshop in which learners practice a useful task.” Around it, she places questions rather than topics. “Assessment” becomes “What could a learner produce that would reveal whether they can perform the task?” “Customers” becomes “Which part of preparing a workshop do educators find difficult enough to seek help with?”

This is a curiosity map: a page of connected questions. Draw it on paper, use a document, or arrange notes on a board. Each connection should explain why its question belongs.

She makes three branches. One concerns the educator's preparation problem. One concerns the learner's task. One concerns Fieldwork's possible delivery process. Each branch has a different output. The first may eventually require conversations with educators. The second can begin with a small design exercise. The third can use her recorded preparation attempts.

Beside each question she writes what she currently knows, what she is assuming, and what evidence would change her view. Her ledger already contains much of this material. The map helps her see relationships across the entries. It does not replace their sources or turn an assumption into a fact through proximity to one.

For example, her preparation trials showed that an assistant sometimes produced vague outcomes. That observation supports investigating how to make outcomes inspectable. It does not establish that the same defect is common in independent educators' paid work. She draws a connection between those questions, then labels the second one “external evidence still needed.”

A crowded map is not necessarily a better map. If a question is interesting but unrelated to a near-term decision, she puts it at the edge with a short explanation of the possible connection. The page should make the next inquiry easier to choose. If its main effect is to display how much remains unknown, reduce it until it can support a decision.

## Follow one branch far enough to expose a test

To make the learner branch concrete, Maya returns to the action-list workshop proposed in the fifth practice specimen. Its proposed audience is adults who use meeting notes for follow-up. The notes, audience, and workshop remain synthetic teaching examples. The earlier output supplies a candidate task and review criteria; Maya's next inquiry will examine whether the activity actually gives learners a chance to use them.

She gives the workshop a provisional duration of thirty minutes. She keeps the earlier vague wording—“Participants will understand effective meeting follow-up”—in the history so she can see why the action-list outcome was proposed. The outcome is clearer now, but the activity is still undecided. A discussion of follow-up could sound relevant without requiring anyone to produce the promised action list.

Her first impulse for the next inquiry is, “How do I make the workshop more engaging?” She can imagine many answers: a story, a discussion, an attractive worksheet, or a timed challenge. None resolves the immediate problem. She still would not know whether the learner performed the task. She records engagement as a possible later concern and moves inward to the missing decision.

The revised question is, “Will the proposed activity produce an action list that someone can check against the commitments in the notes?” She returns to the provisional criteria already recorded: each action should correspond to an agreement; owners and deadlines should appear only when supported; missing details should remain visible. She now needs to apply those criteria to an actual example rather than merely repeat them.

The criteria can themselves be challenged by inspecting the input and output. A beautifully stated requirement may still permit a weak exercise or reject a valid answer. Maya's next piece of work will test what the proposed criteria let her notice and whether her activity exposes the relevant decisions.

One branch now leads to a manageable next step: create fictional notes, make an action list, and examine which errors the brief would help her detect. The market branch stays open for a later inquiry.

## Choose what to investigate now

A useful question can still be the wrong question for today. Some require access you do not have. Some matter only after another uncertainty is resolved. Some offer a large answer at a cost that would overwhelm the current project. Selection involves these practical conditions as well as intellectual interest.

Maya compares three options. She could study the market for workshop-design services, investigate how to evaluate a proposed learner task, or learn a new tool for generating worksheets. The tool would be enjoyable to explore and could produce a visible result quickly. But producing worksheets would commit her to an output before she had established what that output should help someone do.

The market question matters enormously. She cannot resolve it through an afternoon of invented personas, however. She can prepare a question for a future conversation and identify what evidence she would need. The design question is both important and accessible now: her own draft supplies an input, and she can inspect a small result without contacting anyone.

She chooses it. Her explanation is short: “The brief cannot guide useful preparation until I can tell whether its proposed activity practices the stated task. I can expose that defect with a synthetic example.” The explanation makes the trade-off reviewable. She has postponed a market inquiry rather than forgotten it.

Do not turn this comparison into elaborate arithmetic unless you have a reason. Assigning precise scores to unknown benefits can create an appearance of analysis without better information. Write the reason for your choice in ordinary language. Include what you are delaying and when you will reconsider it.

The best selection may be the question that removes a dependency. Before learning how to automate a report, learn who uses it and which decision it supports. Before comparing storage tools, find out what you need to retrieve. Before designing a sophisticated agent, establish what an acceptable result would look like when you do the work yourself.

## Match the evidence to the uncertainty

Different questions deserve different kinds of answers. A definition may be resolved by consulting a reliable source and using the concept correctly. A question about how your procedure behaves requires an attempt. A question about another person's difficulty requires evidence from that person's situation. Confusing these categories is a common way to stop investigating too soon.

Maya can inspect whether her proposed checklist catches an invented deadline. She cannot infer from that inspection that real educators want a checklist. She can ask an assistant to suggest possible objections to the brief. She cannot count those suggestions as customer objections she has observed. Each method can help, provided its result is named accurately.

Suppose she finds three published workshop templates containing similar headings. That establishes a feature of those examples. It does not establish why their authors chose the headings, how often people use them, or whether the headings improve learning. She may still borrow an idea, but she should describe the choice as a design hypothesis rather than a research conclusion.

In the map, record the evidence route beside each selected question. For the action-list exercise, Maya writes “inspect a synthetic before-and-after output against the notes.” For the educator problem, she writes “future consent-based conversations about recent preparation work.” For a general learning claim, she writes “read eligible research and preserve the tested task and population.”

If you cannot yet reach the people whose evidence you need, identify useful preparation and leave the original question open. The map should show the dependency.

## Give the session an ending

Maya defines an ending before opening another source. She will finish when she has a revised learner outcome, one practice input, and a comparison showing whether her proposed check can detect at least one meaningful error. If she cannot produce those, she will name the missing concept and choose a smaller next exercise.

She sets aside forty minutes for this attempt. That duration is an example of a working constraint, not a research-based optimum. A reader with ten available minutes can choose a smaller output. A reader investigating something consequential may need several sessions and informed review. The point is to notice the limit rather than discover hours later that the session had none.

Halfway through, she realizes that her fictional notes are too clean. Every action has a clear owner and date. Almost any checklist would appear to work. She adds one unresolved suggestion and one commitment with no deadline. The input now lets her examine the distinction she cares about.

When the forty minutes end, the brief is better specified, but the workshop has not been delivered. Her completion note preserves both facts. She has a candidate design worth testing further, and no observed learner result. Ending the inquiry does not require pretending the larger question is answered.

“I have enough to choose the next experiment” is a legitimate stopping point. Record why the evidence supports that choice and which larger question it leaves unresolved.

## Keep the side question without following it

During the exercise, Maya wonders whether a digital form could automatically turn notes into an action list. It is a reasonable idea. It is also a different inquiry. Building it now would add interface decisions, data handling, and tool behavior to an exercise intended to clarify a learner task.

She records the question in a parking area: “Could a form support this exercise after the manual version works?” Beside it, she writes a return condition: “Revisit if repeated preparation shows that assembling examples is a bottleneck.” The condition is more useful than a generic promise to return later. It explains what would make the question important.

Recording the question takes only a few lines. She does not collect a full set of tools in anticipation. A parked question should be cheap to maintain. Otherwise, the parking area becomes another obligation competing with the work it was supposed to protect.

External records can reduce the demands of holding everything in mind. Cognitive offloading research examines this broader practice and its consequences, rather than treating every use of an external aid as either beneficial or harmful. Using a small question record here is the book's practical adaptation. ([Risko & Gilbert, 2016](https://doi.org/10.1016/j.tics.2016.07.002))

You can delete a parked question when it no longer matters. Accumulation does not mean that every thought must survive. Preserve the question when it has a plausible future use, enough context to be understood, and a reason to return. The later memory chapters will make this selection more deliberate.

## A real build log preserves the next question

The TFIS build-log presentation ends with a compact template connecting a main question with a preceding experiment, a recorded insight, and a subsequent curiosity. The form preserves a relationship that a list of completed projects can lose: where the next question came from. It is a way to document development, not evidence that every experiment succeeded. ([The Future Is Solo, 2026, slide 48](https://docs.google.com/presentation/d/1dvbBGs22QvtGogevZ6f5mf8YQE7WDAPBwYlclhTyctI/edit#slide=id.g3eb40a63305_0_7))

An earlier entry, labeled Daily Court, connects several preceding experiments to a question about putting judgment into an agent system. It identifies checking the compounding value of the work as a next step. That entry records an investigation agenda; it does not establish that compounding has occurred. ([The Future Is Solo, 2026, slide 31](https://docs.google.com/presentation/d/1dvbBGs22QvtGogevZ6f5mf8YQE7WDAPBwYlclhTyctI/edit#slide=id.g3eec6c2c179_0_22))

The build log keeps an intended benefit beside the work needed to investigate it. That connection is useful in Maya's much smaller project too.

Maya's record can preserve the same connection without imitating the technical project. Her question about a learner task came from a defect in her earlier brief. Her attempt produced a revised check. The next inquiry should retain those parents so she can explain why it exists. Accumulation begins when a new question carries useful evidence from the work that preceded it.

## Use an assistant to sharpen attention

An assistant can help you see gaps, but a broad request for interesting questions can produce a list much larger than you can use. Maya already has enough possible directions. She needs a comparison tied to the document in front of her.

She supplies the provisional brief and asks for questions whose answers would change a specific design decision. She asks the assistant to identify the sentence that gave rise to each question and distinguish missing information from a suggested improvement. The output is easier to inspect because it must point back to something she actually provided.

One suggestion concerns learners' preferred visual style. Maya cannot explain how answering it would resolve the current task mismatch, so she sets it aside. Another asks whether the learner must identify missing commitments or merely format supplied ones. That distinction changes the practice input. She keeps it and writes her own tentative answer before asking for further help.

The model's ability to generate questions should not determine the agenda by itself. Evaluate each suggestion against the decision, evidence route, and time boundary you selected. If a suggestion reveals a more fundamental problem, change the agenda explicitly and explain why. You are allowed to revise the inquiry without drifting into an unrecorded one.

You can do all of this without AI. Read the brief aloud, underline claims that lack evidence, and ask what would make a proposed outcome inspectable. A peer can offer an alternative interpretation. The capability you are developing is the selection and pursuit of the inquiry; the assistant is one way to support that work.

## Bring the practice into your own domain

For a service professional, the starting gap may appear in a client brief. A request to “improve communication” contains many possible projects. A curiosity map can separate message clarity, missing decisions, audience mismatch, and delivery problems. Choose one uncertainty you can inspect with authorized examples. Keep assumptions about the client's motives separate from the observed document defect.

For an educator, begin with a moment when learners can repeat an explanation but struggle to do something with it. Specify the task before selecting another teaching tool. Your first inquiry might concern whether the practice activity presents the same kind of decision as the final task. You will need actual learner attempts to investigate learning effects; a well-designed worksheet alone cannot supply that evidence.

For a software builder, a vague interest in adding AI might become a question about a particular user action. Can someone find the right record? Can they tell whether a proposed change succeeded? You can examine a paper sketch or a manual walkthrough before writing code. Separate uncertainty about user need from uncertainty about technical implementation.

Carry the relationship into your domain: an unfinished output exposes a gap, the gap affects a decision, and an inquiry produces evidence that changes or clarifies the work.

## Field assignment: make curiosity usable

Complete the [curiosity map](../artifacts/03-curiosity-map.md) for your project. Begin with the unfinished output and add only enough questions to show the main uncertainties. Connect each serious candidate to a decision. Mark what is observed, assumed, or still unknown. Then choose one inquiry you can attempt with the access and time you actually have.

Before consulting an assistant, explain why you selected it. Name the most attractive alternative and why it can wait. This thinking check reveals whether you have made a choice or merely followed the most recent suggestion. You may consult your documents afterward to correct the details.

Run one bounded attempt. Keep the input, the result, and a short revision note. The map passes this chapter's practice check when someone can identify what you investigated, why it mattered, what evidence you used, and what changed in the work. A page containing only topic names has not yet reached that point.

If the answer changes nothing, inspect the question. Perhaps it was too broad, unrelated to a decision, or already answered by material you possessed. If you cannot obtain the required evidence, choose a preparatory question and label the original unresolved. If you keep exceeding the time boundary, reduce the promised output instead of removing the ending.

Maya leaves with `curiosity-map-v1` linked to `claim-evidence-ledger-v1` and her provisional workshop brief. Her selected inquiry concerns a checkable learner task; the demand question remains open. Next she needs to phrase the inquiry precisely enough that an assistant, a peer, or her future self can help investigate it. That is the work of [Chapter 4](04-the-question-is-the-unit-of-learning.md).

## References

Gruber, M. J., Gelman, B. D., & Ranganath, C. (2014). States of curiosity modulate hippocampus-dependent learning via the dopaminergic circuit. *Neuron, 84*(2), 486–496. https://doi.org/10.1016/j.neuron.2014.08.060

Risko, E. F., & Gilbert, S. J. (2016). Cognitive offloading. *Trends in Cognitive Sciences, 20*(9), 676–688. https://doi.org/10.1016/j.tics.2016.07.002

The Future Is Solo. (2026). *The Future Is Solo 20260910* [Google Slides presentation]. https://docs.google.com/presentation/d/1dvbBGs22QvtGogevZ6f5mf8YQE7WDAPBwYlclhTyctI/edit

<!-- sources: gruber2014, risko2016, tfis-experiments-20260910 -->
